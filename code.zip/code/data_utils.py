import pandas as pd
from collections import defaultdict

def load_triplets(file_path):
    """Load triplets from file"""
    return pd.read_csv(file_path, sep='\t', header=None, names=['head', 'relation', 'tail'])

def get_entity_degrees(triplets):
    """Calculate entity degrees"""
    degrees = defaultdict(int)
    for head, _, tail in triplets.values:
        degrees[head] += 1
        degrees[tail] += 1
    return degrees

def get_one_hop_neighbors(entity, triplets, max_degree=20, is_head=True):
    """Get top neighbors based on degree (handles both head/tail cases)"""
    degrees = get_entity_degrees(triplets)
    if is_head:
        neighbors = triplets[triplets['head'] == entity][['relation', 'tail']].values
        format_str = lambda rel, tail: f"{entity}-{rel}-{tail}"
    else:
        neighbors = triplets[triplets['tail'] == entity][['head', 'relation']].values
        format_str = lambda head, rel: f"{head}-{rel}-{entity}"
    
    sorted_neighbors = sorted(neighbors, key=lambda x: degrees[x[1]], reverse=True)
    return [format_str(*neighbor) for neighbor in sorted_neighbors[:max_degree]]