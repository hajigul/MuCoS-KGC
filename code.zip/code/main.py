from config import Config
from data_utils import load_triplets
from dataset import KGDataset
from model_utils import create_model, create_optimizer
from train import train_epoch, evaluate_model
from utils import save_results

def main():
    # Load configuration
    cfg = Config()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Load data
    train_df = load_triplets(cfg.TRAIN_FILE_PATH)
    valid_df = load_triplets(cfg.VALID_FILE_PATH)
    test_df = load_triplets(cfg.TEST_FILE_PATH)
    
    # Prepare relations
    all_relations = pd.concat([train_df['relation'], valid_df['relation'], test_df['relation']]).unique()
    rel_to_idx = {rel: idx for idx, rel in enumerate(all_relations)}
    
    # Create Dataset and DataLoader
    tokenizer = AutoTokenizer.from_pretrained(cfg.MODEL_NAME)
    all_triplets = pd.concat([train_df, valid_df, test_df])
    
    train_dataset = KGDataset(train_df, tokenizer, rel_to_idx, all_triplets)
    train_loader = DataLoader(train_dataset, batch_size=cfg.BATCH_SIZE, shuffle=True)
    
    # Initialize model and optimizer
    model = create_model(cfg.MODEL_NAME, len(all_relations), device)
    optimizer = create_optimizer(model, cfg.LEARNING_RATE)
    
    # Training loop
    for epoch in range(cfg.NUM_EPOCHS):
        print(f"Epoch {epoch+1}/{cfg.NUM_EPOCHS}")
        train_loss = train_epoch(model, train_loader, optimizer, device)
        print(f"Train Loss: {train_loss:.4f}")
        
        # Validation and testing would go here
        # results = evaluate_model(...)
        # save_results(results, cfg.MODEL_SAVE_PATH)

if __name__ == "__main__":
    main()