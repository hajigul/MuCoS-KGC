import os

def save_results(results, save_path, filename="test_results.txt"):
    """Save evaluation results to file"""
    os.makedirs(save_path, exist_ok=True)
    file_path = os.path.join(save_path, filename)
    with open(file_path, 'a') as f:
        f.write("\t".join([f"{k}: {v:.4f}" for k, v in results.items()]) + "\n")