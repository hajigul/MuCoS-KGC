import torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer

class KGDataset(Dataset):
    def __init__(self, triplets, tokenizer, relation_to_idx, all_triplets, max_degree=20):
        self.triplets = triplets
        self.tokenizer = tokenizer
        self.relation_to_idx = relation_to_idx
        self.all_triplets = all_triplets
        self.max_degree = max_degree

    def __len__(self):
        return len(self.triplets)

    def __getitem__(self, idx):
        row = self.triplets.iloc[idx]
        head, relation, tail = row['head'], row['relation'], row['tail']
        
        # Get neighbors
        head_neighbors = get_one_hop_neighbors(head, self.all_triplets, self.max_degree, is_head=True)
        tail_neighbors = get_one_hop_neighbors(tail, self.all_triplets, self.max_degree, is_head=False)
        
        # Create input sequence
        input_text = f"{head} [SEP] {' '.join(head_neighbors)} [SEP] {tail} [SEP] {' '.join(tail_neighbors)}"
        inputs = self.tokenizer(
            input_text,
            return_tensors="pt",
            padding="max_length",
            truncation=True,
            max_length=128
        )
        
        return {
            'input_ids': inputs['input_ids'].squeeze(0),
            'attention_mask': inputs['attention_mask'].squeeze(0),
            'labels': torch.tensor(self.relation_to_idx[relation])
        }