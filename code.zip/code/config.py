# Configuration parameters
class Config:
    # File paths
    TRAIN_FILE_PATH = '/home/user/23h1710_KGC/KEGG50k/train.txt'
    VALID_FILE_PATH = '/home/user/23h1710_KGC/KEGG50k/valid.txt'
    TEST_FILE_PATH = '/home/user/23h1710_KGC/KEGG50k/test.txt'
    MODEL_SAVE_PATH = '/home/user/23h1710_KGC/KEGG50k/BERT_R_Prediction_dis'
    
    # Model parameters
    MODEL_NAME = "distilbert-base-uncased"
    NUM_EPOCHS = 50
    BATCH_SIZE = 64
    MAX_DEGREE = 20
    MAX_LENGTH = 128
    LEARNING_RATE = 0.0001