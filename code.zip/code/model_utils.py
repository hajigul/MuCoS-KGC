import torch
from transformers import AutoModelForSequenceClassification, AdamW

def create_model(model_name, num_labels, device):
    """Initialize model and move to device"""
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)
    return model.to(device)

def create_optimizer(model, lr):
    """Create AdamW optimizer"""
    return AdamW(model.parameters(), lr=lr)